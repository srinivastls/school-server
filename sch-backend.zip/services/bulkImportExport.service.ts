import { randomBytes, randomUUID } from 'crypto';
import * as bcrypt from 'bcryptjs';
import { ADAPTERS, Adapter } from './bulkAdapters';
import { prisma } from '../config';

const getSchoolId = (req: any): string | undefined => req.user?.schoolId;
const getUserId = (req: any): string | undefined => req.user?.id;
const safeModel = (key: string): any => {
  const adapter = ADAPTERS[key];
  if (!adapter) throw new Error(`Unsupported module: ${key}`);
  return (prisma as any)[adapter.model];
};
const isBlank = (v: any) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
function convertValue(adapter: Adapter, field: string, value: any) {
  if (isBlank(value)) return undefined; // empty spreadsheet cells are omitted, never erase on update
  if (adapter.dates?.includes(field)) {
    const d = value instanceof Date ? value : new Date(String(value));
    if (Number.isNaN(d.getTime())) throw new Error(`${field} must be a valid date`);
    return d;
  }
  if (adapter.numbers?.includes(field)) {
    const n = Number(value); if (!Number.isFinite(n)) throw new Error(`${field} must be numeric`); return n;
  }
  if (adapter.booleans?.includes(field)) {
    if (typeof value === 'boolean') return value;
    const s = String(value).trim().toLowerCase();
    if (['true','1','yes','y'].includes(s)) return true;
    if (['false','0','no','n'].includes(s)) return false;
    throw new Error(`${field} must be true/false`);
  }
  if (field === 'siblings' && typeof value === 'string') {
    try { return JSON.parse(value); } catch { throw new Error('siblings must contain valid JSON'); }
  }
  return typeof value === 'string' ? value.trim() : value;
}
function scopedData(key: string, row: Record<string, any>, schoolId: string, adapter: Adapter) {
  const data: Record<string, any> = {};
  for (const field of adapter.fields) if (Object.prototype.hasOwnProperty.call(row, field)) {
    const v = convertValue(adapter, field, row[field]); if (v !== undefined) data[field] = v;
  }
  if (key !== 'examSubjects') data.schoolId = schoolId;
  if (key === 'classes') {
    const year = row.academicYearId;
    if (year) data.academicYearId = String(year);
  }
  if (key === 'exams') {
    const year = row.academicYearId;
    if (year) data.academicYearId = String(year);
  }
  return data;
}
function whereFor(key: string, row: Record<string, any>, schoolId: string, adapter: Adapter) {
  if (adapter.key.includes('+')) {
    const parts = adapter.key.split('+'); const where: any = key === 'examSubjects' ? { exam: { schoolId } } : { schoolId };
    for (const p of parts) { if (isBlank(row[p])) { if (p === 'academicYearId' && ['classes','exams'].includes(key)) continue; throw new Error(`Missing unique key: ${p}`); } where[p] = p === 'date' ? new Date(row[p]) : row[p]; }
    if (['classes','exams'].includes(key) && !where.academicYearId) throw new Error('academicYearId is required to identify this record');
    return where;
  }
  if (adapter.key === 'id') {
    if (isBlank(row.id)) return null;
    return key === 'examSubjects' ? { id: String(row.id), exam: { schoolId } } : { id: String(row.id), schoolId };
  }
  if (isBlank(row[adapter.key])) return null;
  const where: any = key === 'examSubjects' ? { [adapter.key]: row[adapter.key], exam: { schoolId } } : { schoolId, [adapter.key]: row[adapter.key] };
  if (key === 'classes') {
    if (!row.academicYearId) throw new Error('academicYearId is required to identify a class');
    where.academicYearId = String(row.academicYearId);
  }
  return where;
}
async function validateRelations(key: string, row: any, schoolId: string) {
  const check = async (model: string, id: any, label: string) => {
    if (!id) return;
    const found = await (prisma as any)[model].findFirst({ where: { id: String(id), schoolId }, select: { id: true } });
    if (!found) throw new Error(`${label} does not exist in this school`);
  };
  if (key === 'students') { await check('class',row.classId,'classId'); await check('section',row.sectionId,'sectionId'); }
  if (key === 'sections') await check('class',row.classId,'classId');
  if (key === 'subjects') await check('class',row.classId,'classId');
  if (key === 'examSubjects') { await check('exam',row.examId,'examId'); await check('class',row.classId,'classId'); await check('subject',row.subjectId,'subjectId'); }
  if (key === 'examTimetables') { await check('exam',row.examId,'examId'); await check('class',row.classId,'classId'); await check('subject',row.subjectId,'subjectId'); }
  if (key === 'marks') { await check('student',row.studentId,'studentId'); const s = await (prisma as any).examSubject.findFirst({where:{id:String(row.examSubjectId),exam:{schoolId}},select:{id:true}}); if(!s) throw new Error('examSubjectId does not exist in this school'); }
  if (key === 'attendance') { await check('student',row.studentId,'studentId'); await check('class',row.classId,'classId'); await check('section',row.sectionId,'sectionId'); }
}
export async function getImportMetadata() { const { IMPORT_MODULES, EXPORT_MODULES } = await import('./bulkAdapters'); return { importModules: IMPORT_MODULES, exportModules: EXPORT_MODULES }; }
export async function stageImport(req: any, moduleKey: string, originalFileName: string, rows: any[], fieldMap: Record<string,string> = {}) {
  const schoolId = getSchoolId(req), userId = getUserId(req), adapter = ADAPTERS[moduleKey];
  if (!schoolId || !userId) throw new Error('Authenticated school and user are required');
  if (!adapter?.writable) throw new Error('This module is export-only or unsupported for import');
  if (!Array.isArray(rows) || !rows.length) throw new Error('The uploaded file contains no data rows');
  if (rows.length > 10000) throw new Error('Maximum 10,000 rows per import');
  const headers = Object.keys(rows[0] || {});
  if (!headers.length) throw new Error('No column headers found');
  const normalize = (h:string) => h.trim().replace(/[\s_-]+/g,'').toLowerCase();
  const autoField = (h:string) => { const direct = adapter.fields.find(f=>normalize(f)===normalize(h)); if(direct) return direct; const aliases:Record<string,string>={studentname:'name',fullname:'name',admissionnumber:'admissionNo',admissionno:'admissionNo',fathername:'fatherName',mothername:'motherName',class:'classId',section:'sectionId',subjectcode:'code',subjectname:'name',examname:'name',dateofbirth:'dob',dateofjoining:'doj',phonenumber:'phone',rollno:'rollNumber',staffname:'name',emailaddress:'email',employeeid:'employeeId',jobtitle:'designation'}; const alias=aliases[normalize(h)]; return alias && adapter.fields.includes(alias) ? alias : undefined; };
  const resolvedMap:Record<string,string>={}; for(const h of headers){const target=Object.prototype.hasOwnProperty.call(fieldMap,h) ? fieldMap[h] : autoField(h); if(target && (adapter.fields.includes(target)||['id','academicYearId'].includes(target))) resolvedMap[h]=target;}
  const recognized = Object.keys(resolvedMap);
  const mappedFields = Object.values(resolvedMap);
  const missing = adapter.requiredOnCreate.filter(f => !mappedFields.includes(f));
  const normalized: any[] = [], errors: any[] = [];
  for (let i=0;i<rows.length;i++) {
    const raw = rows[i] || {}, rowErrors: string[] = [];
    const row: any = {};
    for (const [header,value] of Object.entries(raw)) {
      const field = resolvedMap[String(header)];
      if (field) row[field] = value;
    }
    // Required fields are enforced only for new records; existing rows may be partial updates.
    try {
      const where = whereFor(moduleKey,row,schoolId,adapter);
      const existing = where ? await safeModel(moduleKey).findFirst({where}) : null;
      if (!existing) for (const f of adapter.requiredOnCreate) if (isBlank(row[f])) rowErrors.push(`Missing required field for new record: ${f}`);
      if (!recognized.length) rowErrors.push('No recognized columns found');
      if (moduleKey === 'exams' && row.type && !['UNIT_TEST','MID_TERM','FINAL','OTHER'].includes(String(row.type))) rowErrors.push('type must be UNIT_TEST, MID_TERM, FINAL, or OTHER');
      if (moduleKey === 'attendance' && row.status && !['PRESENT','ABSENT','LATE','HALF_DAY','HOLIDAY'].includes(String(row.status))) rowErrors.push('Invalid attendance status');
      if (moduleKey === 'students' && row.status && !['ACTIVE','TRANSFERRED','GRADUATED','DROPPED'].includes(String(row.status))) rowErrors.push('Invalid student status');
      if (moduleKey === 'teachers') { if (row.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(row.email))) rowErrors.push('email must be a valid email address'); if (row.role && !['TEACHER','ADMIN'].includes(String(row.role).toUpperCase())) rowErrors.push('role must be TEACHER or ADMIN'); }
      if (moduleKey === 'marks' && row.marksObtained !== undefined && row.marksObtained !== '' && (!Number.isFinite(Number(row.marksObtained)) || Number(row.marksObtained)<0)) rowErrors.push('marksObtained must be a non-negative number');
      await validateRelations(moduleKey,row,schoolId);
      // Run field conversion during validation.
      for (const field of adapter.fields) if (Object.prototype.hasOwnProperty.call(row,field)) convertValue(adapter,field,row[field]);
    } catch (e:any) { rowErrors.push(e.message || 'Validation failed'); }
    normalized.push(row); if(rowErrors.length) errors.push({rowNumber:i+2,errors:rowErrors,values:row});
  }
  const id = randomUUID();
  const expiresAt = new Date(Date.now()+24*60*60*1000);
  await (prisma as any).bulk_import_sessions.create({data:{id,school_id:schoolId,created_by_user_id:userId,module:moduleKey,status:errors.length?'UPLOADED':'READY',original_file_name:originalFileName,row_count:rows.length,valid_rows:rows.length-errors.length,invalid_rows:errors.length,payload:{rows:normalized,headers,recognizedHeaders:recognized,fieldMap:resolvedMap,availableFields:[...adapter.fields,...(['id','academicYearId'].filter(f=>!adapter.fields.includes(f)))],ignoredHeaders:headers.filter(h=>!recognized.includes(h)),missingRequiredHeaders:missing},errors:errors.length?errors:null,expires_at:expiresAt,updated_at:new Date()}});
  return { sessionId:id, module:moduleKey, totalRows:rows.length, validRows:rows.length-errors.length, invalidRows:errors.length, headers, recognizedHeaders:recognized, fieldMap:resolvedMap, availableFields:[...adapter.fields,...(['id','academicYearId'].filter(f=>!adapter.fields.includes(f)))], ignoredHeaders:headers.filter(h=>!recognized.includes(h)), missingRequiredHeaders:missing, errors, preview:normalized.slice(0,20) };
}
export async function commitImport(req: any, sessionId: string, mode: 'create'|'update'|'both') {
  const schoolId=getSchoolId(req), userId=getUserId(req); if(!schoolId||!userId) throw new Error('Authenticated school and user are required');
  const session = await (prisma as any).bulk_import_sessions.findFirst({where:{id:sessionId,school_id:schoolId,created_by_user_id:userId}});
  if(!session) throw new Error('Import session not found');
  if(session.expires_at < new Date()) throw new Error('Import session expired; upload again');
  if(session.status==='COMMITTED') throw new Error('This import has already been committed');
  const payload:any=session.payload, rows:any[]=payload.rows, adapter=ADAPTERS[session.module];
  if(!adapter?.writable) throw new Error('Unsupported import module');
  const rowErrors = Array.isArray(session.errors)?session.errors:[];
  const invalidNumbers = new Set(rowErrors.map((e:any)=>e.rowNumber));
  let created=0, updated=0, skipped=0; const failures:any[]=[]; const credentials:any[]=[];
  for(let i=0;i<rows.length;i++) {
    const row=rows[i]; if(invalidNumbers.has(i+2)) { skipped++; continue; }
    try {
      const where=whereFor(session.module,row,schoolId,adapter);
      const existing=where ? await safeModel(session.module).findFirst({where}) : null;
      if(existing && mode==='create') { skipped++; continue; }
      if(!existing && mode==='update') { skipped++; continue; }
      const data=scopedData(session.module,row,schoolId,adapter);
      if(session.module==='marks') { data.enteredByUserId=userId; }
      if(session.module==='teachers') { data.role = String(data.role || '').toUpperCase(); if (!['TEACHER','ADMIN'].includes(data.role)) throw new Error('role must be TEACHER or ADMIN'); }
      if(session.module==='attendance') { data.markedByUserId=userId; }
      if(existing) { delete data.schoolId; if(session.module==='marks') { delete data.enteredByUserId; if(existing.isFinalized) throw new Error('Finalized marks cannot be overwritten'); } await safeModel(session.module).update({where:{id:existing.id},data}); updated++; }
      else { if(session.module==='teachers') { const temporaryPassword = randomBytes(12).toString('base64url'); data.passwordHash = await bcrypt.hash(temporaryPassword, 12); data.isActive = data.isActive ?? true; const account = await safeModel(session.module).create({data}); credentials.push({name:account.name,email:account.email,temporaryPassword}); created++; continue; } if(session.module==='classes' || session.module==='exams') { if(!row.academicYearId) throw new Error('academicYearId is required for new records'); data.academicYearId=String(row.academicYearId); }
        if(session.module==='marks' && row.isFinalized) throw new Error('Import cannot finalize marks');
        await safeModel(session.module).create({data}); created++; }
    } catch(e:any) { failures.push({rowNumber:i+2,error:e.message||'Commit failed'}); skipped++; }
  }
  await (prisma as any).bulk_import_sessions.update({where:{id:session.id},data:{status:failures.length?'FAILED':'COMMITTED',committed_at:new Date(),errors:failures.length?failures:session.errors,updated_at:new Date()}});
  return {created,updated,skipped,failures,...(session.module==='teachers'?{credentials}: {})};
}
export async function createIndividualStaff(req:any, input:any) {
  const schoolId=getSchoolId(req), userId=getUserId(req);
  if(!schoolId || !userId) throw new Error('Authenticated school and user are required');
  const name=String(input?.name||'').trim(), email=String(input?.email||'').trim().toLowerCase(), role=String(input?.role||'').trim().toUpperCase();
  if(!name || !email || !role) throw new Error('name, email, and role are required');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('email must be a valid email address');
  if(!['TEACHER','ADMIN'].includes(role)) throw new Error('role must be TEACHER or ADMIN');
  const existing=await (prisma as any).user.findFirst({where:{schoolId,email},select:{id:true}});
  if(existing) throw new Error('An account with this email already exists in this school');
  const temporaryPassword=randomBytes(12).toString('base64url');
  const passwordHash=await bcrypt.hash(temporaryPassword,12);
  const account=await (prisma as any).user.create({data:{schoolId,name,email,role,passwordHash,phone:input.phone?String(input.phone).trim():undefined,designation:input.designation?String(input.designation).trim():undefined,department:input.department?String(input.department).trim():undefined,employeeId:input.employeeId?String(input.employeeId).trim():undefined,isActive:input.isActive===false?false:true}});
  return {staff:{id:account.id,name:account.name,email:account.email,role:account.role,phone:account.phone,designation:account.designation,department:account.department,employeeId:account.employeeId,isActive:account.isActive},temporaryPassword};
}

export async function exportRows(req:any,moduleKey:string,filters:any={}) {
  const schoolId=getSchoolId(req), adapter=ADAPTERS[moduleKey];
  if(!schoolId) throw new Error('Authenticated school is required');
  if(!adapter) throw new Error('Unsupported module');
  const where:any=moduleKey==='examSubjects'?{exam:{schoolId}}:{schoolId};
  const nonEmpty=(v:any)=>v!==undefined && v!==null && String(v).trim()!=='';
  const asText=(v:any)=>String(v).trim();
  const validDate=(value:any,label:string)=>{const v=asText(value); if(v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new Error(`${label} must use YYYY-MM-DD format`); return v;};
  const dateRange=(field:string)=>{
    const from=validDate(filters.dateFrom,'dateFrom'), to=validDate(filters.dateTo,'dateTo');
    if(from && to && from>to) throw new Error('dateFrom must be on or before dateTo');
    if(from || to) where[field]={...(from?{gte:new Date(`${from}T00:00:00.000Z`)}:{}),...(to?{lte:new Date(`${to}T23:59:59.999Z`)}:{})};
  };
  // Shared filters are applied only to modules with matching schema fields/relations.
  if(nonEmpty(filters.academicYearId)) {
    const year=asText(filters.academicYearId);
    if(['classes','exams'].includes(moduleKey)) where.academicYearId=year;
    if(moduleKey==='attendance') where.academicYearId=year;
    if(['marks','examSubjects','examTimetables'].includes(moduleKey)) {
      if(moduleKey==='marks') where.examSubject={...(where.examSubject||{}),exam:{academicYearId:year,schoolId}};
      else where.exam={...(where.exam||{}),academicYearId:year,schoolId};
    }
  }
  if(moduleKey==='students') {
    if(nonEmpty(filters.classId)) where.classId=asText(filters.classId);
    if(nonEmpty(filters.sectionId)) where.sectionId=asText(filters.sectionId);
    if(nonEmpty(filters.status)) where.status=asText(filters.status).toUpperCase();
    if(nonEmpty(filters.gender)) where.gender=asText(filters.gender);
    if(nonEmpty(filters.category)) where.category=asText(filters.category);
    if(nonEmpty(filters.search)) where.OR=[{name:{contains:asText(filters.search),mode:'insensitive'}},{admissionNo:{contains:asText(filters.search),mode:'insensitive'}},{fatherName:{contains:asText(filters.search),mode:'insensitive'}}];
  }
  if(moduleKey==='marks') {
    if(nonEmpty(filters.classId)) where.examSubject={...(where.examSubject||{}),classId:asText(filters.classId),exam:{...(where.examSubject?.exam||{}),schoolId}};
    if(nonEmpty(filters.examId)) where.examSubject={...(where.examSubject||{}),examId:asText(filters.examId),exam:{...(where.examSubject?.exam||{}),schoolId}};
    if(nonEmpty(filters.subjectId)) where.examSubject={...(where.examSubject||{}),subjectId:asText(filters.subjectId),exam:{...(where.examSubject?.exam||{}),schoolId}};
    if(nonEmpty(filters.studentId)) where.studentId=asText(filters.studentId);
    if(nonEmpty(filters.isAbsent) && ['true','false'].includes(asText(filters.isAbsent).toLowerCase())) where.isAbsent=asText(filters.isAbsent).toLowerCase()==='true';
    if(nonEmpty(filters.isFinalized) && ['true','false'].includes(asText(filters.isFinalized).toLowerCase())) where.isFinalized=asText(filters.isFinalized).toLowerCase()==='true';
    if(nonEmpty(filters.search)) where.student={...(where.student||{}),OR:[{name:{contains:asText(filters.search),mode:'insensitive'}},{admissionNo:{contains:asText(filters.search),mode:'insensitive'}},{fatherName:{contains:asText(filters.search),mode:'insensitive'}}]};
  }
  if(moduleKey==='attendance') {
    if(nonEmpty(filters.classId)) where.classId=asText(filters.classId);
    if(nonEmpty(filters.sectionId)) where.sectionId=asText(filters.sectionId);
    if(nonEmpty(filters.status)) where.status=asText(filters.status).toUpperCase();
    if(nonEmpty(filters.studentId)) where.studentId=asText(filters.studentId);
    if(nonEmpty(filters.search)) where.student={OR:[{name:{contains:asText(filters.search),mode:'insensitive'}},{admissionNo:{contains:asText(filters.search),mode:'insensitive'}},{fatherName:{contains:asText(filters.search),mode:'insensitive'}}]};
    dateRange('date');
  }
  if(['sections','subjects','examSubjects','examTimetables'].includes(moduleKey) && nonEmpty(filters.classId)) where.classId=asText(filters.classId);
  if(['examSubjects','examTimetables'].includes(moduleKey)) {
    if(nonEmpty(filters.examId)) where.examId=asText(filters.examId);
    if(nonEmpty(filters.subjectId)) where.subjectId=asText(filters.subjectId);
  }
  if(moduleKey==='exams' && nonEmpty(filters.type)) where.type=asText(filters.type).toUpperCase();
  if(moduleKey==='classes' && nonEmpty(filters.isCompleted) && ['true','false'].includes(asText(filters.isCompleted).toLowerCase())) where.isCompleted=asText(filters.isCompleted).toLowerCase()==='true';
  if(moduleKey==='teachers') {
    if(nonEmpty(filters.role) && ['TEACHER','ADMIN','PARENT','PRINCIPAL'].includes(asText(filters.role).toUpperCase())) where.role=asText(filters.role).toUpperCase();
    if(nonEmpty(filters.isActive) && ['true','false'].includes(asText(filters.isActive).toLowerCase())) where.isActive=asText(filters.isActive).toLowerCase()==='true';
    if(nonEmpty(filters.department)) where.department={contains:asText(filters.department),mode:'insensitive'};
    if(nonEmpty(filters.search)) where.OR=[{name:{contains:asText(filters.search),mode:'insensitive'}},{email:{contains:asText(filters.search),mode:'insensitive'}},{employeeId:{contains:asText(filters.search),mode:'insensitive'}}];
  }
  if(moduleKey==='transactions') {
    const dateFrom=validDate(filters.dateFrom,'dateFrom'), dateTo=validDate(filters.dateTo,'dateTo'), month=nonEmpty(filters.month)?asText(filters.month):'';
    if(month && !/^\d{4}-\d{2}$/.test(month)) throw new Error('month must use YYYY-MM format');
    if(dateFrom && dateTo && dateFrom>dateTo) throw new Error('dateFrom must be on or before dateTo');
    if(month) where.date={startsWith:month};
    else if(dateFrom || dateTo) where.date={...(dateFrom?{gte:dateFrom}:{}),...(dateTo?{lte:dateTo+'\uffff'}:{})};
    // Transaction.classNumber is the historical class value recorded with the receipt.
    if(nonEmpty(filters.classNumber)) where.classNumber=asText(filters.classNumber);
    if(nonEmpty(filters.classId) || nonEmpty(filters.sectionId) || nonEmpty(filters.studentId) || nonEmpty(filters.search)) {
      const studentWhere:any={schoolId};
      if(nonEmpty(filters.classId)) studentWhere.classId=asText(filters.classId);
      if(nonEmpty(filters.sectionId)) studentWhere.sectionId=asText(filters.sectionId);
      if(nonEmpty(filters.studentId)) studentWhere.id=asText(filters.studentId);
      if(nonEmpty(filters.search)) studentWhere.OR=[{name:{contains:asText(filters.search),mode:'insensitive'}},{admissionNo:{contains:asText(filters.search),mode:'insensitive'}},{fatherName:{contains:asText(filters.search),mode:'insensitive'}}];
      where.student={is:studentWhere};
    }
    if(nonEmpty(filters.paymentMode)) where.paymentMode=asText(filters.paymentMode).toUpperCase();
    if(nonEmpty(filters.receiptNumber)) where.receiptNumber={contains:asText(filters.receiptNumber),mode:'insensitive'};
  }

  const includeByModule:Record<string,any>={
    students:{class:{select:{classNumber:true,displayName:true}},section:{select:{sectionName:true}}},
    marks:{student:{select:{admissionNo:true,name:true,fatherName:true,classId:true,sectionId:true,rollNumber:true,class:{select:{classNumber:true,displayName:true}},section:{select:{sectionName:true}}}},examSubject:{select:{maxMarks:true,passingMarks:true,subject:{select:{name:true,code:true}},class:{select:{classNumber:true,displayName:true}},exam:{select:{name:true,academicYearId:true,academicYear:{select:{name:true}}}}}}},
    attendance:{student:{select:{admissionNo:true,name:true,fatherName:true,rollNumber:true}},class:{select:{classNumber:true,displayName:true}},section:{select:{sectionName:true}},academicYear:{select:{name:true}}},
    examSubjects:{exam:{select:{name:true,academicYearId:true,academicYear:{select:{name:true}}}},subject:{select:{name:true,code:true}},class:{select:{classNumber:true,displayName:true}}},
    examTimetables:{exam:{select:{name:true,academicYearId:true,academicYear:{select:{name:true}}}},subject:{select:{name:true,code:true}},class:{select:{classNumber:true,displayName:true}}},
    sections:{class:{select:{classNumber:true,displayName:true}}}, subjects:{class:{select:{classNumber:true,displayName:true}}}, exams:{academicYear:{select:{name:true}}}, classes:{academicYear:{select:{name:true}}}, teachers:{},
    transactions:{student:{select:{admissionNo:true,name:true,fatherName:true,rollNumber:true,classId:true,sectionId:true,class:{select:{classNumber:true,displayName:true}},section:{select:{sectionName:true}}}},recordedByUser:{select:{name:true,email:true,role:true}}}
  };
  const orderBy:any=moduleKey==='students'?{name:'asc'}:moduleKey==='transactions'?[{date:'asc'},{receiptNumber:'asc'}]:moduleKey==='teachers'?{name:'asc'}:moduleKey==='attendance'?{date:'asc'}:{id:'asc'};
  const rows=await safeModel(moduleKey).findMany({where,orderBy,take:50000,include:includeByModule[moduleKey]||undefined});
  const iso=(v:any)=>v instanceof Date?v.toISOString():v;
  return rows.map((r:any)=>{
    const out:Record<string,any>={};
    for(const f of adapter.fields) if(Object.prototype.hasOwnProperty.call(r,f)) out[f]=iso(r[f]);
    if(moduleKey==='students') Object.assign(out,{className:r.class?.displayName||r.class?.classNumber||'',sectionName:r.section?.sectionName||''});
    if(moduleKey==='marks') Object.assign(out,{admissionNo:r.student?.admissionNo||'',studentName:r.student?.name||'',fatherName:r.student?.fatherName||'',rollNumber:r.student?.rollNumber||'',className:r.student?.class?.displayName||r.student?.class?.classNumber||'',sectionName:r.student?.section?.sectionName||'',examName:r.examSubject?.exam?.name||'',academicYearName:r.examSubject?.exam?.academicYear?.name||'',subjectName:r.examSubject?.subject?.name||'',subjectCode:r.examSubject?.subject?.code||'',maxMarks:r.examSubject?.maxMarks??'',passingMarks:r.examSubject?.passingMarks??''});
    if(moduleKey==='attendance') Object.assign(out,{admissionNo:r.student?.admissionNo||'',studentName:r.student?.name||'',fatherName:r.student?.fatherName||'',rollNumber:r.student?.rollNumber||'',className:r.class?.displayName||r.class?.classNumber||'',sectionName:r.section?.sectionName||'',academicYearName:r.academicYear?.name||''});
    if(moduleKey==='examSubjects') Object.assign(out,{examName:r.exam?.name||'',academicYearName:r.exam?.academicYear?.name||r.exam?.academicYearId||'',subjectName:r.subject?.name||'',subjectCode:r.subject?.code||'',className:r.class?.displayName||r.class?.classNumber||''});
    if(moduleKey==='examTimetables') Object.assign(out,{examName:r.exam?.name||'',academicYearName:r.exam?.academicYear?.name||r.exam?.academicYearId||'',subjectName:r.subject?.name||'',subjectCode:r.subject?.code||'',className:r.class?.displayName||r.class?.classNumber||''});
    if(moduleKey==='sections') Object.assign(out,{className:r.class?.displayName||r.class?.classNumber||''});
    if(moduleKey==='subjects') Object.assign(out,{className:r.class?.displayName||r.class?.classNumber||''});
    if(moduleKey==='exams') Object.assign(out,{academicYearName:r.academicYear?.name||''});
    if(moduleKey==='classes') Object.assign(out,{academicYearName:r.academicYear?.name||''});
    if(moduleKey==='teachers') Object.assign(out,{staffName:r.name||'',accountStatus:r.isActive?'ACTIVE':'INACTIVE'});
    if(moduleKey==='transactions') Object.assign(out,{admissionNo:r.student?.admissionNo||'',studentName:r.student?.name||'',fatherName:r.student?.fatherName||'',rollNumber:r.student?.rollNumber||'',studentClassName:r.student?.class?.displayName||r.student?.class?.classNumber||'',sectionName:r.student?.section?.sectionName||'',recordedByName:r.recordedByUser?.name||'',recordedByEmail:r.recordedByUser?.email||'',recordedByRole:r.recordedByUser?.role||''});
    return out;
  });
}


/** School-scoped lookup values used by the export filter dropdowns. */
export async function getExportFilterOptions(req:any, moduleKey:string, filters:any={}) {
  const schoolId=getSchoolId(req);
  if(!schoolId) throw new Error('Authenticated school is required');
  if(!ADAPTERS[moduleKey]) throw new Error('Unsupported module');
  const yearId=String(filters.academicYearId||'').trim();
  const classId=String(filters.classId||'').trim();
  const sectionId=String(filters.sectionId||'').trim();
  const [academicYears, classes, sections, students, exams, subjects, staff, txClasses, paymentModes, studentGenders, studentCategories] = await Promise.all([
    (prisma as any).academicYear.findMany({where:{schoolId},select:{id:true,name:true,isCurrent:true,startDate:true},orderBy:{startDate:'desc'},take:100}),
    (prisma as any).class.findMany({where:{schoolId,...(yearId?{academicYearId:yearId}:{})},select:{id:true,classNumber:true,displayName:true,academicYearId:true},orderBy:{classNumber:'asc'},take:500}),
    (prisma as any).section.findMany({where:{schoolId,...(classId?{classId}:{})},select:{id:true,sectionName:true,classId:true},orderBy:{sectionName:'asc'},take:1000}),
    (prisma as any).student.findMany({where:{schoolId,...(classId?{classId}:{}),...(sectionId?{sectionId}:{})},select:{id:true,admissionNo:true,name:true,fatherName:true,classId:true,sectionId:true},orderBy:{name:'asc'},take:5000}),
    (prisma as any).exam.findMany({where:{schoolId,...(yearId?{academicYearId:yearId}:{})},select:{id:true,name:true,academicYearId:true,type:true},orderBy:{startDate:'desc'},take:1000}),
    (prisma as any).subject.findMany({where:{schoolId,...(classId?{classId}:{})},select:{id:true,name:true,code:true,classId:true},orderBy:{name:'asc'},take:2000}),
    (prisma as any).user.findMany({where:{schoolId},select:{department:true},distinct:['department'],take:200}),
    (prisma as any).transaction.findMany({where:{schoolId},select:{classNumber:true},distinct:['classNumber'],take:100}),
    (prisma as any).transaction.findMany({where:{schoolId},select:{paymentMode:true},distinct:['paymentMode'],take:20}),
    (prisma as any).student.findMany({where:{schoolId,gender:{not:null}},select:{gender:true},distinct:['gender'],take:100}),
    (prisma as any).student.findMany({where:{schoolId,category:{not:null}},select:{category:true},distinct:['category'],take:200})
  ]);
  return {
    academicYears:academicYears.map((x:any)=>({value:x.id,label:`${x.name}${x.isCurrent?' (Current)':''}`})),
    classes:classes.map((x:any)=>({value:x.id,label:x.displayName||x.classNumber,academicYearId:x.academicYearId,classNumber:x.classNumber})),
    sections:sections.map((x:any)=>({value:x.id,label:x.sectionName,classId:x.classId})),
    students:students.map((x:any)=>({value:x.id,label:`${x.admissionNo} — ${x.name}${x.fatherName?` (Parent: ${x.fatherName})`:''}`,classId:x.classId,sectionId:x.sectionId,admissionNo:x.admissionNo,name:x.name})),
    exams:exams.map((x:any)=>({value:x.id,label:x.name,academicYearId:x.academicYearId,type:x.type})),
    subjects:subjects.map((x:any)=>({value:x.id,label:`${x.name}${x.code?` (${x.code})`:''}`,classId:x.classId})),
    roles:[{value:'TEACHER',label:'Teacher'},{value:'ADMIN',label:'Admin'},{value:'PRINCIPAL',label:'Principal'},{value:'PARENT',label:'Parent'}],
    studentStatuses:[{value:'ACTIVE',label:'Active'},{value:'TRANSFERRED',label:'Transferred'},{value:'GRADUATED',label:'Graduated'},{value:'DROPPED',label:'Dropped'}],
    attendanceStatuses:[{value:'PRESENT',label:'Present'},{value:'ABSENT',label:'Absent'},{value:'LATE',label:'Late'},{value:'HALF_DAY',label:'Half day'},{value:'HOLIDAY',label:'Holiday'}],
    genders:studentGenders.filter((x:any)=>x.gender).map((x:any)=>({value:String(x.gender),label:String(x.gender)})),
    categories:studentCategories.filter((x:any)=>x.category).map((x:any)=>({value:String(x.category),label:String(x.category)})),
    examTypes:[{value:'UNIT_TEST',label:'Unit test'},{value:'MID_TERM',label:'Mid-term'},{value:'FINAL',label:'Final'},{value:'OTHER',label:'Other'}],
    paymentModes:paymentModes.map((x:any)=>({value:String(x.paymentMode),label:String(x.paymentMode).replace(/_/g,' ')})),
    receiptClasses:txClasses.filter((x:any)=>x.classNumber).map((x:any)=>({value:String(x.classNumber),label:String(x.classNumber)})),
    departments:staff.filter((x:any)=>x.department).map((x:any)=>({value:String(x.department),label:String(x.department)})),
    booleanOptions:[{value:'true',label:'Yes'},{value:'false',label:'No'}]
  };
}
