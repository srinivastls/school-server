import { Express } from "express";

import {
  studentPromotionControllers,
} from "../controllers";

import {
  authJwt,
} from "../middlewares";


/* ============================================================
   STUDENT PROMOTION ROUTES
============================================================ */

export const useStudentPromotionRoutes = (
  app: Express
) => {

  /* ----------------------------------------------------------
     GET STUDENTS FOR PROMOTION
  ---------------------------------------------------------- */

  app.get(
    "/api/academic-year/promotion/students",

    authJwt.verifyToken,

    authJwt.isPrincipalOrAdmin,

    studentPromotionControllers
      .getPromotionStudents
  );

  app.post(
  "/api/academic-year/promotion/student",
  authJwt.verifyToken,
  authJwt.isPrincipalOrAdmin,
  studentPromotionControllers
    .processStudentPromotion
);

app.post(
  "/api/academic-year/promotion/students/bulk",
  authJwt.verifyToken,
  authJwt.isPrincipalOrAdmin,
  studentPromotionControllers
    .processBulkStudentPromotion
);

};